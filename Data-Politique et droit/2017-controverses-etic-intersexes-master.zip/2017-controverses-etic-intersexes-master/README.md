# Controverse


https://controverses.telecom-paristech.fr

Each Role have a specific folder, please deliver your assignement in the folder of your role. 