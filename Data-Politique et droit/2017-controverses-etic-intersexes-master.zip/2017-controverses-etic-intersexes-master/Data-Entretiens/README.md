# Your space 

You can edit this markdown document to explain what is inside your folder. 

Please commit and push your data  in a [CSV format](https://en.wikipedia.org/wiki/Comma-separated_values) and your analysis in a [RTF document](https://en.wikipedia.org/wiki/Rich_Text_Format), both inside this folder. 

More information about this class on: the [website](https://controverses.telecom-paristech.fr)


